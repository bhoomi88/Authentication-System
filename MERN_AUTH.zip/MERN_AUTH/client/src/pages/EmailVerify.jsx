import React, { useContext, useEffect, useRef } from 'react';
import { AppContent } from '../context/AppContext';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const EmailVerify = () => {
  const navigate = useNavigate();
  const { backendUrl, isLoggedin, userData, getUserData } = useContext(AppContent);
  const inputRefs = useRef([]);

  const handleInput = (e, index) => {
    if (e.target.value.length > 0 && index < inputRefs.current.length - 1) {
      inputRefs.current[index + 1].focus();
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && e.target.value === '' && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handlePaste = (e) => {
    const paste = e.clipboardData.getData('text');
    const pasteArray = paste.slice(0, 6).split('');
    pasteArray.forEach((char, index) => {
      if (inputRefs.current[index]) {
        inputRefs.current[index].value = char;
      }
    });
  };

  const onSubmitHandler = async (e) => {
    e.preventDefault();
    try {
      const otpArray = inputRefs.current.map((input) => input.value);
      const otp = otpArray.join('');

      const { data } = await axios.post(backendUrl + '/api/auth/verify-account', { otp });
      if (data.success) {
        toast.success(data.message);
        getUserData();
        navigate('/');
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  useEffect(() => {
    if (isLoggedin && userData?.isAccountVerified) {
      navigate('/');
    }
  }, [isLoggedin, userData, navigate]);

  return (
    <div className="flex items-center justify-center min-h-screen px-6 bg-gradient-to-r from-yellow-100 via-pink-100 to-purple-200 relative">
      {/* Logo */}
      <img
        onClick={() => navigate('/')}
        src="https://cdn3.iconfinder.com/data/icons/animals-wildlife/128/dove-olive-branch-1024.png"
        alt="Logo"
        className="absolute top-6 left-6 w-10 sm:w-14 cursor-pointer"
      />

      <form
        onSubmit={onSubmitHandler}
        className="bg-white bg-opacity-90 backdrop-blur-md p-10 rounded-xl shadow-xl w-full max-w-md border border-gray-200"
      >
        <h1 className="text-3xl font-bold text-black mb-2 text-center">Verify Your Email</h1>
        <p className="text-sm text-gray-700 mb-6 text-center">
          Enter the 6-digit code sent to your email address
        </p>

        <div className="flex justify-between mb-8 gap-2" onPaste={handlePaste}>
          {Array(6)
            .fill(0)
            .map((_, index) => (
              <input
                key={index}
                type="text"
                maxLength="1"
                required
                className="w-12 h-12 text-2xl text-center border border-gray-300 bg-white text-black rounded-md shadow focus:outline-none focus:ring-2 focus:ring-pink-400"
                ref={(el) => (inputRefs.current[index] = el)}
                onInput={(e) => handleInput(e, index)}
                onKeyDown={(e) => handleKeyDown(e, index)}
              />
            ))}
        </div>

        <button
          type="submit"
          className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-full font-semibold shadow-md hover:from-pink-500 hover:to-orange-400 transition duration-300"
        >
          Verify Email
        </button>
      </form>
    </div>
  );
};

export default EmailVerify;
