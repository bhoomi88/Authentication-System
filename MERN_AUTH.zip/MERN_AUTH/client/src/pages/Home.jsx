import React from 'react';
import Navbar from '../components/Navbar';
import Header from '../components/Header';

const Home = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-r from-yellow-100 via-pink-100 to-purple-200">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <main className="flex-grow flex items-center justify-center px-4">
        <Header />
      </main>
    </div>
  );
};

export default Home;
