import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppContent } from '../context/AppContext';
import { assets } from '../assets/assets';
import { toast } from 'react-toastify';
import axios from 'axios';

const Navbar = () => {
  const { userData, setIsLoggedin, setUserData, backendUrl } = useContext(AppContent);
  const navigate = useNavigate();

  const sendVerificationOtp = async () => {
    try {
      axios.defaults.withCredentials = true;
      const { data } = await axios.post(backendUrl + '/api/auth/send-verify-otp');
      if (data.success) {
        navigate('/email-verify');
        toast.success(data.message);
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };
const logout = async () => {
  try {
    const { data } = await axios.post(
      backendUrl + '/api/auth/logout',
      {},
      {
        withCredentials: true,
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    if (data.success) {
      setIsLoggedin(false);
      setUserData(null);
      toast.success(data.message);

      // Navigate after a short delay to avoid race conditions
      setTimeout(() => {
window.location.href = '/';
      }, 100);
    } else {
      toast.error(data.message);
    }
  } catch (error) {
    toast.error(error.message);
  }
};



  return (
    <nav className="bg-gradient-to-r from-yellow-100 via-pink-100 to-purple-200 text-white shadow-md py-4 px-6 flex justify-between items-center relative">
      {/* Logo */}
      <img
        onClick={() => navigate('/')}
        src="https://cdn3.iconfinder.com/data/icons/animals-wildlife/128/dove-olive-branch-1024.png"
        alt="Logo"
        className="w-12 sm:w-20 cursor-pointer"
      />

      {/* User Dropdown or Login Button */}
      {userData ? (
        <div className="w-8 h-8 flex justify-center items-center rounded-full bg-white text-teal-700 relative group cursor-pointer font-semibold">
          {userData.name[0].toUpperCase()}
          <div className="absolute hidden group-hover:block top-0 right-0 z-10 pt-10">
            <ul className="list-none bg-white text-black rounded shadow-lg text-sm w-36">
              {!userData.isAccountVerified && (
                <li
                  onClick={sendVerificationOtp}
                  className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                >
                  Verify Email
                </li>
              )}
              <li
                onClick={logout}
                className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
              >
                Logout
              </li>
            </ul>
          </div>
        </div>
      ) : (
        <button
          onClick={() => navigate('/login')}
          className="bg-white text-teal-700 px-4 py-2 rounded-full hover:bg-orange-300 transition"
        >
          Login
        </button>
      )}
    </nav>
  );
};

export default Navbar;
