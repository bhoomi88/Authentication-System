import React, { useContext } from 'react';
import { assets } from '../assets/assets';
import { AppContent } from '../context/AppContext';

const Header = () => {
  const { userData } = useContext(AppContent);

  return (
    <div className="flex flex-col items-center justify-center min-h-[75vh] px-6 text-center rounded-lg">
      <img
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSEXukXhbVnGQOIXjhB9vOk4vyRZgaW9XHkCg&s"
        alt="Profile"
        className="w-32 h-32 sm:w-40 sm:h-40 rounded-full border-4 border-white shadow-lg mb-6"
      />

      <h1 className="flex items-center gap-2 text-2xl sm:text-4xl font-semibold text-purple-600 mb-2">
        Hey {userData ? userData.name : 'Developer'}
        <img className="w-7 sm:w-9 aspect-square" src={assets.hand_wave} alt="Wave" />
      </h1>

      <h2 className="text-3xl sm:text-5xl font-bold text-purple-600 mb-4">
        Welcome to Our App
      </h2>

      <p className="text-purple-400 max-w-xl mb-8 text-sm sm:text-base">
        Ready to explore? Let's take a quick product tour and show you what you can do.
      </p>

      <button
        className="bg-white text-teal-600 font-semibold px-8 py-3 rounded-full shadow-lg hover:scale-105 transition-transform"
      >
        Get Started
      </button>
    </div>
  );
};

export default Header;
